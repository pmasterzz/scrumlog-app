﻿angular.module('app.scrumlog', [])

.controller('ScrumlogCtrl', function ($scope, AuthService) {
    var vm = this;


})