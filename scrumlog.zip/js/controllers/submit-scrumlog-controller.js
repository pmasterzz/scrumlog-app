﻿angular.module('app.submitScrumlog', [])

.controller('SubmitScrumlogCtrl', function ($scope, AuthService, ScrumlogService) {
    var vm = this;
    vm.getAllTeachers = getAllTeachers;
    vm.teachers = vm.getAllTeachers();
    console.log(vm.teachers);
        
    function getAllTeachers() {
        ScrumlogService.getAllTeachers().success(function (data) {
            return data.teachers;
        })
    }

    function submitScrumlog() {
        
    }
    
})