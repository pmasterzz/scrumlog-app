﻿angular.module('app.authService', [])

.factory('AuthService', function ($http) {

    var service = {
        user: {},
        setUser: setUser,
        getUser: getUser,
        login: login,
        checkToken: checkToken
}
    return service;

    function setUser(user) {
        console.log('in function'); 
        this.user = user;
    }
    function getUser() {
        return this.user;
    }

    function login(data) {
        return $http.post('http://localhost:8080/api/login', data);
    }
    function checkToken(data) {
        return $http.post('http://localhost:8080/api/checkToken', data);
    }
})