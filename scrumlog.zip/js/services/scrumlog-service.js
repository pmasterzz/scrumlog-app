﻿angular.module('app.scrumlogService', [])

.factory('ScrumlogService', function ($http, $window) {

    var service = {
        submit: submit,
        getAllTeachers: getAllTeachers
    }
    return service;

    function submit(data) {
        return $http.post('http://localhost:8080/api/submit', data);
    }

    function getAllTeachers() {
        return $http.get('http://localhost:8080/api/getAllTeachers?token=' + $window.localStorage.token);
    }


})