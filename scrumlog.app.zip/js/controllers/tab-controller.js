﻿angular.module('app.tab', [])

.controller('TabController', function ($scope, AuthService, $window, $state, $ionicPopup) {
    
    $scope.showConfirm = function () {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Uitloggen',
            template: 'Weet je zeker dat je uit wilt loggen?',
            buttons: [{
                text: 'Uitloggen', type: 'button-positive', onTap: function (e) {
                    $scope.logout();
                }
            }, { text: 'Annuleren', type: 'button-assertive' }]
        });
    };

    $scope.logout = function () {
        var user = AuthService.getUser();
        var data = {
            Person_ID: user.Person_ID
        };
        AuthService.logout(data).success(function (wha) {
            
        })
        $window.localStorage.clear();
        $state.go('login');
    }
})